<?php

$name = $_GET["name"] ?? "";
$age = $_GET["age"] ?? "";
$address = $_GET["address"] ?? "";
$program = $_GET["program"] ?? "";
$phoneNumber = $_GET["phoneNumber"] ?? "";
$email = $_GET["email"] ?? "";
$linkedin = $_GET["linkedin"] ?? "";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Generator</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div id="maindiv">

        <div id="div">

            <form action="resume.php" method="GET">

                <?php
                echo "<h1>$name</h1>";
                ?>



                <label for="age">Age</label> <br>

                <?php
                if ($age == "") {
                ?>
                    <input type="text" name="age" id="age" placeholder="Enter age">
                <?php
                } else {
                    echo $age;
                }
                ?>

                <br><br>


                <label for="address">Address</label> <br>

                <?php
                if ($address == "") {
                ?>
                    <input type="text" name="address" id="address" placeholder="Enter your address">
                <?php
                } else {
                    echo $address;
                }
                ?>

                <br><br>


                <label for="program">Program</label> <br>

                <?php
                if ($program == "") {
                ?>
                    <select name="program" id="program">
                        <option value="BSIT">Bachelor of Science in Information Technology</option>
                        <option value="BSCS">Bachelor of Science in Computer Science</option>
                        <option value="BSCompE">Bachelor of Science in Computer Engineering</option>
                    </select>
                <?php
                } else {
                    echo $program;
                }
                ?>

                <br><br>


                <label for="phoneNumber">Phone Number</label> <br>

                <?php
                if ($phoneNumber == "") {
                ?>
                    <input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter your phone number">
                <?php
                } else {
                    echo $phoneNumber;
                }
                ?>

                <br><br>


                <label for="email">Email</label> <br>

                <?php
                if ($email == "") {
                ?>
                    <input type="email" name="email" id="email" placeholder="Enter your email">
                <?php
                } else {
                    echo $email;
                }
                ?>

                <br><br>


                <label for="linkedin">LinkedIn</label> <br>

                <?php
                if ($linkedin == "") {
                ?>
                    <input type="text" name="linkedin" id="linkedin" placeholder="Enter your LinkedIn link">
                <?php
                } else {
                    echo $linkedin;
                }
                ?>
            </form>

        </div>

    </div>

</body>

</html>