<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Generator</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div id="maindiv">
        <div id="div">

            <h1>Resume Generator</h1>

            <form action="resume.php" method="get">

                <label for="name">Name</label>
                <br>
                <input type="text" name="name" id="name" placeholder="Enter your name">
                <br><br>

                <label for="age">Age</label>
                <br>
                <input type="text" name="age" id="age" placeholder="Enter age">
                <br><br>

                <label for="address">Address</label>
                <br>
                <input type="text" name="address" id="address" placeholder="Enter your address">
                <br><br>

                <label for="program">Program</label>
                <br>
                <select name="program" id="program">
                    <option value="Bachelor of Science in Information Technology">
                        Bachelor of Science in Information Technology
                    </option>

                    <option value="Bachelor of Science in Computer Science">
                        Bachelor of Science in Computer Science
                    </option>

                    <option value="Bachelor of Science in Computer Engineering">
                        Bachelor of Science in Computer Engineering
                    </option>
                </select>
                <br><br>

                <label for="phoneNumber">Phone Number</label>
                <br>
                <input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter your phone number">
                <br><br>

                <label for="email">Email</label>
                <br>
                <input type="email" name="email" id="email" placeholder="Enter your email">
                <br><br>

                <label for="linkedin">LinkedIn</label>
                <br>
                <input type="text" name="linkedin" id="linkedin" placeholder="Enter your LinkedIn link">
                <br><br>

                <button type="submit" id="submitbtn">Submit</button>
                <button type="reset" id="resetbtn">Reset</button>

            </form>

        </div>
    </div>

</body>

</html>